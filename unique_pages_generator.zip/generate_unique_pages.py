import os
import random
from datetime import datetime

TITLES = ['Discover Onyx Storm in {city}, {country}', 'Fantasy Awaits in {city}: Onyx Storm #3', 'Onyx Storm Now Available in {city}, {country}', 'Epic Dragons and Magic in {city}', "Read Onyx Storm - Rebecca Yarros' Fantasy Hit in {city}"]
DESCRIPTIONS = ["Dive into the Empyrean series' third book, now reaching {city}, {country}.", 'Explore magical realms and dragon lore, newly released for readers in {city}.', 'Join the fantasy revolution from {city} with Onyx Storm by Rebecca Yarros.', 'Uncover secrets of the skies. Now in {city}.', 'A new chapter begins in {city}, where dragons soar and legends awaken.']
IMAGES = ['https://cdn.respirework.com/img1.jpg', 'https://cdn.respirework.com/img2.jpg', 'https://cdn.respirework.com/img3.jpg', 'https://cdn.respirework.com/img4.jpg', 'https://cdn.respirework.com/img5.jpg']

output_dir = "public/pages"
os.makedirs(output_dir, exist_ok=True)

with open("data/locations.txt", "r") as f:
    locations = [line.strip().split(",") for line in f if "," in line]

today = datetime.utcnow().strftime("%Y-%m-%d")

for i, (country, city) in enumerate(locations):
    title_template = random.choice(TITLES)
    desc_template = random.choice(DESCRIPTIONS)
    image_url = random.choice(IMAGES)

    title = title_template.format(city=city, country=country)
    description = desc_template.format(city=city, country=country)
    slug = f"{country.lower()}_{city.lower().replace(' ', '_')}"

    filename = os.path.join(output_dir, f"{slug}.html")
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"""<!DOCTYPE html>
<html lang='en'>
<head>
  <meta charset='UTF-8'>
  <title>{title}</title>
  <meta name='description' content='{description}'>
  <link rel='canonical' href='https://www.respirework.com/pages/{slug}.html'>
  <meta property="og:image" content="{image_url}">
</head>
<body>
  <h1>{title}</h1>
  <img src="{image_url}" alt="Onyx Storm Cover" width="300">
  <p>{description}</p>
  <p><a href="https://payhip.com/b/yLYxv">Buy Now</a></p>
  <footer><small>Generated on {today}</small></footer>
</body>
</html>""")
print(f"✅ Generated {len(locations)} unique pages.")
