# Send Discord webhook notification about the eBook
import requests

webhook_url = "YOUR_DISCORD_WEBHOOK_URL"

data = {
    "content": "**New Promotion**: Get Onyx Storm now at https://www.respirework.com"
}

r = requests.post(webhook_url, json=data)
print("Discord notified:", r.status_code)
