# Suggest an answer to post on Quora manually
answer = """If you're into epic fantasy with dragon-rider wars and moral complexity, you should check out Onyx Storm by Rebecca Yarros.

It’s available here: https://www.respirework.com

It explores destiny, rebellion, and deep character dynamics.
"""
with open("quora_answer.txt", "w") as f:
    f.write(answer)
print("Quora answer generated.")
