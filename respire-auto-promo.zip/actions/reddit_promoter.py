# Draft Reddit post content for manual posting
from datetime import datetime

now = datetime.utcnow().isoformat()
post_title = "Why Onyx Storm is the Fantasy You Need in Your Life"
post_body = f"""If you're a fan of dragons, rebellion, and deep character arcs, don't miss out on *Onyx Storm*.
Get it now at https://www.respirework.com - new chapters & bonuses added weekly!

(Generated at {now})"""

with open("reddit_post_draft.txt", "w") as f:
    f.write(post_title + "\n\n" + post_body)
print("Reddit post draft saved.")
