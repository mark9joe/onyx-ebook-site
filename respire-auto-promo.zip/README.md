# Respire Auto Promo

Automated promo system using GitHub Actions.
- Discord Webhook alerts
- Reddit draft generator
- Quora answer suggestion
- RSS feed pinger

Edit the webhook in `discord_notify.py` and add your GitHub secret if needed.
