import requests

feeds = [
    "https://www.respirework.com/rss/empyrean-series.xml",
    "https://www.respirework.com/rss/rebecca-yarros.xml"
]

pings = [
    "https://rpc.pingomatic.com/",
    "https://rpc.twingly.com/"
]

for feed in feeds:
    for endpoint in pings:
        try:
            r = requests.post(endpoint, data={"url": feed})
            print(f"Pinged {endpoint} for {feed} - {r.status_code}")
        except Exception as e:
            print(f"Failed to ping {endpoint}: {e}")
