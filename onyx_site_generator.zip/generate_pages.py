# generate_pages.py
import os
from datetime import datetime

output_dir = "public/pages"
os.makedirs(output_dir, exist_ok=True)

with open("data/locations.txt", "r") as f:
    locations = [line.strip().split(",") for line in f if "," in line]

batch_size = 100000
today = datetime.utcnow().strftime("%Y-%m-%d")

for i, (country, city) in enumerate(locations[:batch_size]):
    slug = f"{country.lower()}_{city.lower().replace(' ', '_')}"
    filename = os.path.join(output_dir, f"{slug}.html")
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"""
<!DOCTYPE html>
<html lang='en'>
<head>
  <meta charset='UTF-8'>
  <title>Read Onyx Storm in {city}, {country}</title>
  <meta name='description' content='Explore the fantasy world of Onyx Storm from {city}, {country}.'>
  <link rel='canonical' href='https://www.respirework.com/pages/{slug}.html'>
</head>
<body>
  <h1>Onyx Storm Available in {city}, {country}</h1>
  <p>Get your digital copy now from <a href='https://www.respirework.com'>Respirework</a>.</p>
  <p>Generated on {today}</p>
</body>
</html>
""")

print(f"✅ Generated {min(batch_size, len(locations))} pages in '{output_dir}'")
