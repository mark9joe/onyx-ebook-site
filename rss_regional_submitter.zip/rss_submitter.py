import os
import requests

BASE_URL = "https://www.respirework.com/pages/"
DIR = "public/pages"
SEARCH_ENGINES = [
    "http://www.google.com/ping?sitemap=https://www.respirework.com/sitemap.xml",
    "http://www.bing.com/ping?sitemap=https://www.respirework.com/sitemap.xml",
    "https://webmaster.yandex.com/ping?sitemap=https://www.respirework.com/sitemap.xml"
]

def ping_engines():
    for url in SEARCH_ENGINES:
        try:
            res = requests.get(url)
            print(f"✅ Pinged: {url} | Status: {res.status_code}")
        except Exception as e:
            print(f"❌ Failed ping: {url} | Error: {e}")

def submit_to_rss():
    for file in os.listdir(DIR):
        if file.endswith(".html"):
            full_url = BASE_URL + file
            try:
                res = requests.get(f"https://rpc.pingomatic.com/ping/?name=Onyx+Storm&url={full_url}")
                print(f"✅ Submitted to Ping-O-Matic: {full_url}")
            except Exception as e:
                print(f"❌ Ping failed for {full_url}: {e}")

if __name__ == "__main__":
    ping_engines()
    submit_to_rss()
